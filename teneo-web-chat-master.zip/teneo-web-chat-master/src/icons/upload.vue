<template>
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 14.16 14.78">
    <path
      d="M14.84,7.39,10,12.2A1.25,1.25,0,1,0,11.8,14l5.78-5.75a2.34,2.34,0,0,0-.29-3.05,2.34,2.34,0,0,0-3-.29l-8,8C5.26,13.86,6,16,7,17s3.14,1.75,4.1.79l7.84-7.84"
      transform="translate(-5.28 -3.93)"
      style="
        fill: none;
        stroke: currentColor;
        stroke-linecap: round;
        stroke-miterlimit: 10;
      "
    />
  </svg>
</template>
