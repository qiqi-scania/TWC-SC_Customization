<template>
  <svg xmlns="http://www.w3.org/2000/svg" version="1.1" id="Layer_1" x="0" y="0" viewBox="0 0 29 29"
       xml:space="preserve">
    <path d="M14.5 17a3.5 3.5 0 01-3.5-3.5v-8a3.5 3.5 0 117 0v8a3.5 3.5 0 01-3.5 3.5z"/>
    <path
        d="M20 10v3.5c0 3.032-2.468 5.5-5.5 5.5S9 16.532 9 13.5V10H7v3.5c0 3.796 2.837 6.934 6.5 7.425V25H10v2h9v-2h-3.5v-4.075c3.663-.491 6.5-3.629 6.5-7.425V10h-2z"/></svg>
</template>
