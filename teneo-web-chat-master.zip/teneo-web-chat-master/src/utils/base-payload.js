export default function basePayload() {
    return {"handledState": {"handled": false}}
}